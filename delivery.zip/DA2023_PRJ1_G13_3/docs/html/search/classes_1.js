var searchData=
[
  ['compare_0',['Compare',['../structCompare.html',1,'']]]
];
